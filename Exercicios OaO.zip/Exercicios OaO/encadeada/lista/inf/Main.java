package encadeada.lista.inf;

public class Main {
	public static void main (String[] args) {
		Lista lis = new Lista();
		lis.append("Luan");
		lis.append("Juca");
		lis.append("a");
		lis.append("b");	
		lis.append("c");
		lis.append("d");
		lis.exclui(4);
		lis.append("4");
		lis.imprimeDados();
		System.out.println(lis.get(2));
	}
}
