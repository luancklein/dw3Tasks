package encadeada.lista.inf;

public class Lista {
	boolean primeiroExiste = false;
	No primeiro;
	No ultimo;
	No atual;
	int size = 0;
	
	public void append(String valor){
	
		this.atual = new No(valor);
		this.atual.mudaIndice(this.size);
		
		System.out.println("Entrou1!");
		
		if (primeiroExiste == false){
			this.primeiro = this.atual;
			this.primeiroExiste = true;
			this.ultimo = this.atual;
		}
		else{
			No next = this.primeiro;
			while (next.proximo != null){
				next = next.proximo;
			}
			next.proximo = this.atual;
			this.atual.anterior = next;
			this.ultimo = this.atual;
		}	
		this.size += 1;
		
	}
	public void imprimeDados(){
		No next = this.ultimo;
		while (next != null){
			System.out.println(next.str + " " + next.indice);
			next = next.anterior;
		}
	}
	
	public void exclui(int indi){
		No next = this.primeiro;
		while (next.indice != indi){
			next = next.proximo;
		}
		
		if (indi == 0)
		{
			No pro = next.proximo;
			this.primeiro = pro;
			pro.anterior = null;	
		}
		else if (next.proximo == null){
			No ant = next.anterior;
			this.ultimo = ant;
			ant.proximo = null;
			this.ultimo = ant;
		}
		else if (next != null){
			No ant = next.anterior;
			No pro = next.proximo;
			ant.proximo = pro;
			pro.anterior = ant;
		}
		
		atualizaIndice();
		this.size -= 1;
	}
	
	public void atualizaIndice(){
		int ind = 0;
		No next = this.primeiro;
		while (next != null){
			next.indice = ind;
			ind += 1;
			next = next.proximo;
		}
		
	}
	
	public String get(int indi){
		No next = this.primeiro;
		while (next != null){
			if (next.indice == indi){
				return next.str;
			}
		
			next = next.proximo;
		}
		return "Nenhum valor encontrado!";
	}
	
	

}
