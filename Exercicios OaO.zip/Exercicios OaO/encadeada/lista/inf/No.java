package encadeada.lista.inf;

public class No {
	String str = "";
	int indice = 0;
	No proximo;
	No anterior;
	
	public No(String st){
		this.str = st;
	}
	
	public void mudaIndice(int numero){
		this.indice = numero;
	}
	
	public String imprimeValor(){
		System.out.println(this.str);
		return this.str;
	}
}
