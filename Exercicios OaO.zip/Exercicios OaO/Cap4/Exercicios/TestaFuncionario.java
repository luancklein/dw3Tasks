package Cap4.Exercicios;

public class TestaFuncionario {
	
	public static void main(String[] args) {

	
	Funcionario f1 = new Funcionario();
		f1.nome = "Hugo";
		f1.salario = 100.00;
		Funcionario f2 = f1;
	
	


		f1.dataDeEntrada.dia = 12;
		f1.dataDeEntrada.mes = 02;
		f1.dataDeEntrada.ano = 2009;

		if (f1 == f2) {
		System.out.println("iguais");
		} else {
		System.out.println("diferentes");
		}
		
		f1.mostra();
	
	}
}
