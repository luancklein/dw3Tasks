package Cap4.Exercicios;

public class Data {

	int dia;
	int mes;
	int ano;
	
	public String formatada(){
		return this.dia + "/" + this.mes + "/" + this.ano;
	}
}

