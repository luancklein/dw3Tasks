package Cap4.Exercicios;

public class Funcionario {
	
	String nome;
	Double salario;
	Data dataDeEntrada = new Data();
	String rg;
	String departamento;
	

	public void recebeAumento(double aumento) {
		this.salario += aumento;
		}
	
	public double calculaGanhoAnual() {
			return this.salario * 12;
		}
	
	public void mostra()
	{
		System.out.println("Nome: " + this.nome);
		System.out.println("Sal�rio: R$" + this.salario);
		System.out.println("Departamento: " + this.departamento);
		System.out.println("Data de entrada: " + this.dataDeEntrada.formatada());

		System.out.println("RG: " + this.rg);
	}
	

}





