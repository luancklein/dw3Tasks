package exercicios.inf;

public class MyClass {
	public int fatorial(int num){
		int resultado = 1;
		for (int a = num; a > 0; a --)
		{
			resultado *= a;
		}
		return resultado;
	}
	
	public int fibonacci(int num){
		int a = 1;
		int b = 1;
		int c = a + b;
		if (num == 0){
			return a;
		}
		else if (num == 1){
			return b;
		}
		num -= 2;
		while (num > 0){
			c = a + b;
			a = b;
			b = c;
			num -= 1;
		}
		return c;
	}
}
