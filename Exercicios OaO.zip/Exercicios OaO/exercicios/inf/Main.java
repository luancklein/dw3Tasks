package exercicios.inf;

public class Main {
	public static void main (String[] args) {
		MyClass classe = new MyClass();
		
		System.out.println(classe.fibonacci(4));
		System.out.println(classe.fatorial(5));
	}

}
